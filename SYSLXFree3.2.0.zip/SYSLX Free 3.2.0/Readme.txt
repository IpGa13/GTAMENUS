SYSLX Free - (3.2.0) for GTA V [1.66]

>> GO in GTA-V Story Mode <<

>> Drag the syslxfree folder into the "Put the syslxfree folder into this folder" Shortcut to install the needed menu files<<
______________________________________________________________________________

>> Open the syslgame Injector.exe and enter as dll name: "SYSLX Free 3.2.0.dll", then hit enter and wait until its injected. (GTA V already needs to be open!) <<
______________________________________________________________________________

>> To open the Menu Press "F4" or "Num *" <<
______________________________________________________________________________

>> Offical Discord Server: https://discord.gg/a6F4Ryju9a <<
______________________________________________________________________________

>> Offical SYSLX Website: https://syslx-menu.com/forum/ <<
______________________________________________________________________________

>> Offical SYSLX Store: https://syslx.mysellix.io/ <<
______________________________________________________________________________

>>><<HAPPY CHEATING>><<<<<
______________________________________________________________________________


-> Troubleshooting <-
1. Try to inject while GTA V is in borderless or window mode.
2. If this doesnt help, contact our support on our Discord server. 